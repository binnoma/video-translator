/**
 * Content Script - Video Translator v3.2 (Bilingual AR/EN)
 * Captures audio directly from video/audio elements using captureStream()
 * Translation overlay is fully draggable!
 */

(function () {
  'use strict';
  if (window.__videoTranslatorLoaded) return;
  window.__videoTranslatorLoaded = true;

  // ── State ──
  let audioCtx = null;
  let mediaStream = null;
  let sourceNode = null;
  let processorNode = null;
  let silentGain = null;
  let samples = [];
  let isCapturing = false;
  let chunkTimer = null;
  let currentVideo = null;
  let overlay = null;
  let hideTimeout = null;
  let lastOriginal = '';
  let lastTranslated = '';
  let overlayLang = 'ar'; // default

  // Drag state
  let isDragging = false;
  let dragStartX = 0;
  let dragStartY = 0;
  let dragOffsetX = 0;
  let dragOffsetY = 0;

  const TARGET_SAMPLE_RATE = 16000;
  const CHUNK_INTERVAL_MS = 4000;

  // ── Overlay i18n ──
  const overlayTexts = {
    ar: { waiting: '⏳ في انتظار الترجمة...', live: 'مباشر', close: 'إغلاق', drag: 'اسحب للتحريك' },
    en: { waiting: 'Waiting for translation...', live: 'LIVE', close: 'Close', drag: 'Drag to move' },
  };

  function ot(key) {
    return (overlayTexts[overlayLang] && overlayTexts[overlayLang][key]) || overlayTexts.en[key];
  }

  // ── Message Listener ──
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.action) {
      case 'startCapture':
        startCapture()
          .then(() => sendResponse({ success: true }))
          .catch(e => sendResponse({ success: false, error: e.message }));
        return true; // async

      case 'stopCapture':
        stopCapture();
        sendResponse({ success: true });
        return false;

      case 'showTranslation':
        displayTranslation(msg.original, msg.translated);
        break;

      case 'showOverlay':
        showOverlay();
        break;

      case 'hideOverlay':
        hideOverlayFn();
        break;

      case 'setLanguage':
        overlayLang = msg.lang || 'ar';
        if (overlay) {
          // Update existing overlay direction
          const isRTL = overlayLang === 'ar';
          overlay.style.direction = isRTL ? 'rtl' : 'ltr';
          // Update waiting text if currently showing
          const waitingEl = overlay.querySelector('.vt-waiting-text');
          if (waitingEl) waitingEl.textContent = ot('waiting');
          const dragHandle = overlay.querySelector('.vt-drag-handle');
          if (dragHandle) dragHandle.title = ot('drag');
          const closeBtn = overlay.querySelector('.vt-close-btn');
          if (closeBtn) closeBtn.title = ot('close');
        }
        break;
    }
  });

  // ═══════════════════════════════════════
  //  Audio Capture Engine
  // ═══════════════════════════════════════

  async function startCapture() {
    if (isCapturing) throw new Error('Capture is already running');

    // 1. Find a video element
    const videos = document.querySelectorAll('video, audio');
    const video =
      Array.from(videos).find(v => !v.paused && v.readyState >= 2) ||
      videos[0];

    if (!video) {
      throw new Error(
        'No video or audio element found on this page. Please open a video first.'
      );
    }

    currentVideo = video;

    // 2. Capture the audio stream from the element
    let stream;
    try {
      stream =
        video.captureStream != null
          ? video.captureStream()
          : video.mozCaptureStream
          ? video.mozCaptureStream()
          : null;
    } catch (e) {
      throw new Error('Cannot capture audio stream: ' + e.message);
    }

    if (!stream || stream.getAudioTracks().length === 0) {
      throw new Error(
        'No audio tracks found in the stream. The video may be muted or have no audio.'
      );
    }

    mediaStream = stream;

    // 3. Set up AudioContext + ScriptProcessor
    audioCtx = new (window.AudioContext || window.webkitAudioContext)({
      sampleRate: 44100,
    });

    if (audioCtx.state === 'suspended') {
      await audioCtx.resume();
    }

    sourceNode = audioCtx.createMediaStreamSource(mediaStream);
    processorNode = audioCtx.createScriptProcessor(4096, 1, 1);
    silentGain = audioCtx.createGain();
    silentGain.gain.value = 0;

    processorNode.onaudioprocess = (e) => {
      if (!isCapturing) return;

      const rawData = e.inputBuffer.getChannelData(0);

      let sum = 0;
      for (let i = 0; i < rawData.length; i++) sum += rawData[i] * rawData[i];
      const rms = Math.sqrt(sum / rawData.length);

      if (rms > 0.001) {
        samples.push(new Float32Array(rawData));
      }
    };

    sourceNode.connect(processorNode);
    processorNode.connect(silentGain);
    silentGain.connect(audioCtx.destination);

    isCapturing = true;
    samples = [];

    chunkTimer = setInterval(sendAudioChunk, CHUNK_INTERVAL_MS);

    showOverlay();

    chrome.runtime.sendMessage({ action: 'captureStarted' }).catch(() => {});
  }

  function stopCapture() {
    isCapturing = false;

    if (chunkTimer) {
      clearInterval(chunkTimer);
      chunkTimer = null;
    }

    sendAudioChunk();

    try { if (processorNode) processorNode.disconnect(); } catch {}
    try { if (sourceNode) sourceNode.disconnect(); } catch {}
    try { if (silentGain) silentGain.disconnect(); } catch {}

    if (audioCtx) {
      audioCtx.close().catch(() => {});
      audioCtx = null;
    }

    if (mediaStream) {
      mediaStream.getTracks().forEach(t => t.stop());
      mediaStream = null;
    }

    processorNode = null;
    sourceNode = null;
    silentGain = null;
    samples = [];
    currentVideo = null;
    lastOriginal = '';
    lastTranslated = '';

    hideOverlayFn();

    chrome.runtime.sendMessage({ action: 'captureStopped' }).catch(() => {});
  }

  function sendAudioChunk() {
    if (samples.length === 0) return;

    const merged = mergeFloat32Arrays(samples);
    samples = [];

    if (merged.length < TARGET_SAMPLE_RATE) return;

    const resampled = resampleAudio(merged, 44100, TARGET_SAMPLE_RATE);
    const wavBase64 = encodeWAVBase64(resampled, TARGET_SAMPLE_RATE);

    chrome.runtime
      .sendMessage({ action: 'audioChunk', data: wavBase64 })
      .catch(() => {});
  }

  // ═══════════════════════════════════════
  //  Audio Processing Utilities
  // ═══════════════════════════════════════

  function mergeFloat32Arrays(arrays) {
    let totalLen = 0;
    for (const a of arrays) totalLen += a.length;
    const merged = new Float32Array(totalLen);
    let offset = 0;
    for (const a of arrays) {
      merged.set(a, offset);
      offset += a.length;
    }
    return merged;
  }

  function resampleAudio(input, fromRate, toRate) {
    if (fromRate === toRate) return input;
    const ratio = fromRate / toRate;
    const newLen = Math.round(input.length / ratio);
    const output = new Float32Array(newLen);
    for (let i = 0; i < newLen; i++) {
      const idx = i * ratio;
      const low = Math.floor(idx);
      const high = Math.min(low + 1, input.length - 1);
      const frac = idx - low;
      output[i] = input[low] * (1 - frac) + input[high] * frac;
    }
    return output;
  }

  function float32ToPCM16(float32) {
    const pcm16 = new Int16Array(float32.length);
    for (let i = 0; i < float32.length; i++) {
      const s = Math.max(-1, Math.min(1, float32[i]));
      pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return pcm16;
  }

  function encodeWAVBase64(samples, sampleRate) {
    const numSamples = samples.length;
    const buf = new ArrayBuffer(44 + numSamples * 2);
    const view = new DataView(buf);

    const writeStr = (offset, str) => {
      for (let i = 0; i < str.length; i++) {
        view.setUint8(offset + i, str.charCodeAt(i));
      }
    };

    writeStr(0, 'RIFF');
    view.setUint32(4, 36 + numSamples * 2, true);
    writeStr(8, 'WAVE');
    writeStr(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeStr(36, 'data');
    view.setUint32(40, numSamples * 2, true);

    const pcm16 = float32ToPCM16(samples);
    for (let i = 0; i < pcm16.length; i++) {
      view.setInt16(44 + i * 2, pcm16[i], true);
    }

    const bytes = new Uint8Array(buf);
    let binary = '';
    const chunkSize = 8192;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      const slice = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
      binary += String.fromCharCode.apply(null, slice);
    }
    return btoa(binary);
  }

  // ═══════════════════════════════════════
  //  Draggable Translation Overlay
  // ═══════════════════════════════════════

  function createOverlay() {
    if (overlay) return;

    overlay = document.createElement('div');
    overlay.id = 'video-translator-overlay';
    overlay.className = 'vt-hidden';
    // Apply direction based on current language
    const isRTL = overlayLang === 'ar';
    overlay.style.direction = isRTL ? 'rtl' : 'ltr';

    overlay.innerHTML = `
      <div class="vt-container">
        <button class="vt-close-btn" title="${ot('close')}">&times;</button>
        <div class="vt-drag-handle" title="${ot('drag')}">
          <div class="vt-drag-dots"></div>
        </div>
        <div class="vt-body">
          <div class="vt-waiting">
            <span class="vt-waiting-text">${ot('waiting')}</span>
          </div>
        </div>
      </div>
    `;

    // Close button
    overlay.querySelector('.vt-close-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      hideOverlayFn();
    });

    // ── Drag: Mouse events ──
    const handleDrag = overlay.querySelector('.vt-drag-handle');

    handleDrag.addEventListener('mousedown', onDragStart);
    handleDrag.addEventListener('touchstart', onDragStart, { passive: false });

    document.addEventListener('mousemove', onDragMove);
    document.addEventListener('mouseup', onDragEnd);
    document.addEventListener('touchmove', onDragMove, { passive: false });
    document.addEventListener('touchend', onDragEnd);

    document.body.appendChild(overlay);

    // Position initially at bottom center
    requestAnimationFrame(() => {
      positionOverlay('bottom-center');
    });
  }

  // ── Drag Handlers ──

  function onDragStart(e) {
    e.preventDefault();
    e.stopPropagation();

    isDragging = true;
    overlay.classList.add('vt-dragging');

    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    const rect = overlay.getBoundingClientRect();
    dragOffsetX = clientX - rect.left;
    dragOffsetY = clientY - rect.top;

    dragStartX = clientX;
    dragStartY = clientY;
  }

  function onDragMove(e) {
    if (!isDragging || !overlay) return;
    e.preventDefault();

    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    let newLeft = clientX - dragOffsetX;
    let newTop = clientY - dragOffsetY;

    // Keep within viewport bounds
    const maxX = window.innerWidth - 60;
    const maxY = window.innerHeight - 30;

    newLeft = Math.max(-overlay.offsetWidth + 60, Math.min(maxX, newLeft));
    newTop = Math.max(0, Math.min(maxY, newTop));

    // Switch to absolute positioning
    overlay.style.bottom = 'auto';
    overlay.style.left = newLeft + 'px';
    overlay.style.top = newTop + 'px';
  }

  function onDragEnd(e) {
    if (!isDragging) return;
    isDragging = false;
    overlay.classList.remove('vt-dragging');
  }

  // ── Position helper ──

  function positionOverlay(mode) {
    if (!overlay) return;
    const rect = overlay.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    if (mode === 'bottom-center') {
      overlay.style.bottom = '20px';
      overlay.style.left = '50%';
      overlay.style.top = 'auto';
      overlay.style.transform = 'translateX(-50%)';
    }
  }

  // ── Show / Hide ──

  function showOverlay() {
    if (!overlay) createOverlay();
    clearTimeout(hideTimeout);
    overlay.classList.remove('vt-hidden');
    overlay.classList.add('vt-visible');
  }

  function hideOverlayFn() {
    if (!overlay) return;
    overlay.classList.remove('vt-visible');
    overlay.classList.add('vt-hidden');
  }

  function displayTranslation(original, translated) {
    if (!overlay) createOverlay();

    if (original === lastOriginal && translated === lastTranslated) return;
    lastOriginal = original;
    lastTranslated = translated;

    const body = overlay.querySelector('.vt-body');
    const isRTL = overlayLang === 'ar';
    body.innerHTML = `
      <div class="vt-live-badge">
        <span class="vt-live-dot"></span>
        ${ot('live')}
      </div>
      <div class="vt-original" style="direction:auto;text-align:${isRTL ? 'right' : 'left'}">${escapeHtml(original)}</div>
      <div class="vt-divider"></div>
      <div class="vt-translated" style="direction:auto;text-align:${isRTL ? 'right' : 'left'}">${escapeHtml(translated)}</div>
    `;

    showOverlay();

    clearTimeout(hideTimeout);
    hideTimeout = setTimeout(hideOverlayFn, 30000);
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Expose for injected scripts
  window.__videoTranslatorReady = true;
  window.__showOverlay = showOverlay;
  window.__hideOverlay = hideOverlayFn;
})();
