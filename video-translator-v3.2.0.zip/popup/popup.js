/**
 * Popup Script - Video Translator v3.2 (Bilingual AR/EN)
 */

// ═══════════════════════════════════════
//  i18n Translations
// ═══════════════════════════════════════

const i18n = {
  en: {
    title: 'Video Translator',
    subtitle: 'Real-time tab audio translation',
    status_connected: 'Server connected',
    status_disconnected: 'Server not running — Start the server first',
    status_checking: 'Checking server...',
    label_source: 'Source',
    label_target: 'Target',
    btn_start: 'Start Capture',
    btn_stop: 'Stop Capture',
    btn_starting: 'Starting...',
    audio_capturing: 'Capturing audio...',
    label_original: 'Original',
    label_translation: 'Translation',
    label_history: 'History',
    btn_clear: 'Clear',
    label_settings: 'Settings',
    setting_server: 'Server URL:',
    setting_chunk: 'Chunk interval (seconds):',
    btn_save: 'Save',
    btn_saved: 'Saved ✓',
    setup_title: 'How to start the server:',
    setup_step1: 'Open the <code>server</code> folder included with the extension',
    setup_step2: 'Open Terminal / CMD in that folder',
    setup_step3: 'Run: <code>node server.js</code>',
    setup_step4: 'Click Settings then <strong>Save</strong> to re-check connection',
    setup_note: '100% Free — No API key or account needed<br>Runs locally on your machine only',
    footer: 'No microphone needed • Captures tab audio directly',
    error_prefix: 'Error: ',
    error_failed: 'Failed to start capture',
    error_no_tab: 'No active tab found',
    error_chrome_page: 'Cannot capture browser internal pages',
    error_no_video: 'No video or audio element found. Please open a video first.',
    error_no_stream: 'Cannot capture audio stream',
    error_no_tracks: 'No audio tracks found. The video may be muted.',
    error_capture_running: 'Capture is already running',
    error_no_server: 'Cannot connect to the page. Try refreshing the tab.',
    // Content overlay
    overlay_waiting: 'Waiting for translation...',
    overlay_live: 'LIVE',
    overlay_close: 'Close',
    overlay_drag_hint: 'Drag to move',
  },

  ar: {
    title: 'مترجم الفيديو',
    subtitle: 'ترجمة فورية لصوت التبويب',
    status_connected: 'متصل بالخادم',
    status_disconnected: 'الخادم غير متصل — شغّل الخادم أولاً',
    status_checking: 'جاري التحقق من الخادم...',
    label_source: 'لغة المصدر',
    label_target: 'لغة الترجمة',
    btn_start: 'بدء الالتقاط',
    btn_stop: 'إيقاف الالتقاط',
    btn_starting: 'جاري البدء...',
    audio_capturing: 'جاري الالتقاط...',
    label_original: 'النص الأصلي',
    label_translation: 'الترجمة',
    label_history: 'سجل الترجمات',
    btn_clear: 'مسح',
    label_settings: 'الإعدادات',
    setting_server: 'رابط الخادم:',
    setting_chunk: 'فترة الالتقاط (ثواني):',
    btn_save: 'حفظ',
    btn_saved: 'تم الحفظ ✓',
    setup_title: 'كيف تشغّل الخادم:',
    setup_step1: 'افتح مجلد <code>server</code> الموجود مع الإضافة',
    setup_step2: 'افتح Terminal / CMD في هذا المجلد',
    setup_step3: 'اكتب: <code>node server.js</code>',
    setup_step4: 'اضغط الإعدادات ثم <strong>حفظ</strong> لإعادة الفحص',
    setup_note: 'مجاني بالكامل — لا يحتاج مفتاح API أو حساب<br>يعمل على جهازك فقط',
    footer: 'بدون مايكروفون • يلتقط صوت التبويب مباشرة',
    error_prefix: 'خطأ: ',
    error_failed: 'فشل في بدء الالتقاط',
    error_no_tab: 'لم يتم العثور على تبويب نشط',
    error_chrome_page: 'لا يمكن التقاط صفحات المتصفح الداخلية',
    error_no_video: 'لا يوجد فيديو أو صوت في الصفحة. افتح فيديو أولاً.',
    error_no_stream: 'لا يمكن التقاط البث الصوتي',
    error_no_tracks: 'لا توجد مسارات صوتية. الفيديو قد يكون صامتاً.',
    error_capture_running: 'الالتقاط يعمل بالفعل',
    error_no_server: 'لا يمكن الاتصال بالصفحة. حاول تحديث التبويب.',
    // Content overlay
    overlay_waiting: '⏳ في انتظار الترجمة...',
    overlay_live: 'مباشر',
    overlay_close: 'إغلاق',
    overlay_drag_hint: 'اسحب للتحريك',
  },
};

// ── DOM Elements ──
const el = {
  langToggle: document.getElementById('langToggle'),
  langToggleText: document.querySelector('.lang-toggle-text'),
  sourceLang: document.getElementById('sourceLang'),
  targetLang: document.getElementById('targetLang'),
  toggleBtn: document.getElementById('toggleBtn'),
  btnText: document.getElementById('btnText'),
  btnIcon: document.getElementById('btnIcon'),
  audioLevel: document.getElementById('audioLevel'),
  audioStatus: document.getElementById('audioStatus'),
  connectionStatus: document.getElementById('connectionStatus'),
  errorMessage: document.getElementById('errorMessage'),
  errorText: document.getElementById('errorText'),
  translationDisplay: document.getElementById('translationDisplay'),
  originalText: document.getElementById('originalText'),
  translatedText: document.getElementById('translatedText'),
  historySection: document.getElementById('historySection'),
  historyList: document.getElementById('historyList'),
  clearHistory: document.getElementById('clearHistory'),
  setupGuide: document.getElementById('setupGuide'),
  settingsToggle: document.getElementById('settingsToggle'),
  settingsPanel: document.getElementById('settingsPanel'),
  serverUrl: document.getElementById('serverUrl'),
  chunkInterval: document.getElementById('chunkInterval'),
  saveSettings: document.getElementById('saveSettings'),
};

// ── State ──
let state = {
  isCapturing: false,
  serverConnected: false,
  serverUrl: 'http://localhost:3000',
  history: [],
  lastOriginal: '',
  lastTranslated: '',
  uiLang: 'ar', // default Arabic since user is Arabic speaker
};

// ═══════════════════════════════════════
//  i18n Engine
// ═══════════════════════════════════════

function t(key) {
  return (i18n[state.uiLang] && i18n[state.uiLang][key]) || i18n.en[key] || key;
}

function applyLanguage() {
  const lang = state.uiLang;
  const html = document.documentElement;
  const body = document.body;

  // Set direction and lang
  html.setAttribute('lang', lang === 'ar' ? 'ar' : 'en');
  html.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
  body.style.direction = lang === 'ar' ? 'rtl' : 'ltr';

  // Update all data-i18n elements
  document.querySelectorAll('[data-i18n]').forEach(elem => {
    const key = elem.getAttribute('data-i18n');
    if (i18n[lang] && i18n[lang][key]) {
      elem.innerHTML = i18n[lang][key];
    }
  });

  // Toggle button text
  el.langToggleText.textContent = lang === 'ar' ? 'EN' : 'عربي';

  // Re-apply dynamic text
  updateUI();
  setConnectionStatus(
    state.serverConnected ? 'connected' :
    el.connectionStatus.classList.contains('checking') ? 'checking' : 'disconnected'
  );

  // Re-render history
  if (state.history.length > 0) renderHistory();

  // Notify content script about language change
  if (state.isCapturing) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'setLanguage',
          lang: state.uiLang,
        }).catch(() => {});
      }
    });
  }
}

function toggleLanguage() {
  state.uiLang = state.uiLang === 'ar' ? 'en' : 'ar';
  chrome.storage.local.set({ uiLang: state.uiLang });
  applyLanguage();
}

// ═══════════════════════════════════════
//  Initialization
// ═══════════════════════════════════════

async function init() {
  const saved = await chrome.storage.local.get([
    'serverUrl', 'sourceLang', 'targetLang', 'chunkInterval', 'uiLang',
  ]);

  // Load UI language
  if (saved.uiLang) state.uiLang = saved.uiLang;
  if (saved.serverUrl) { state.serverUrl = saved.serverUrl; el.serverUrl.value = saved.serverUrl; }
  if (saved.sourceLang) el.sourceLang.value = saved.sourceLang;
  if (saved.targetLang) el.targetLang.value = saved.targetLang;
  if (saved.chunkInterval) el.chunkInterval.value = saved.chunkInterval;

  // Apply language
  applyLanguage();

  // Check server
  await checkServerConnection();

  // Check capture status
  try {
    const status = await chrome.runtime.sendMessage({ action: 'getStatus' });
    if (status && status.isCapturing) {
      state.isCapturing = true;
      updateUI();
      el.audioLevel.classList.remove('hidden');
      startAudioAnimation();
    }
  } catch {}
}

// ═══════════════════════════════════════
//  Server Connection
// ═══════════════════════════════════════

async function checkServerConnection() {
  setConnectionStatus('checking');

  const result = await chrome.runtime.sendMessage({ action: 'checkServer' });

  if (result && result.connected) {
    state.serverConnected = true;
    setConnectionStatus('connected');
    el.setupGuide.classList.add('hidden');
  } else {
    state.serverConnected = false;
    setConnectionStatus('disconnected');
    el.setupGuide.classList.remove('hidden');
  }
}

function setConnectionStatus(status) {
  const elCS = el.connectionStatus;
  elCS.className = 'connection-status ' + status;
  const statusText = elCS.querySelector('.status-text');
  const key = 'status_' + status;
  if (statusText && i18n[state.uiLang] && i18n[state.uiLang][key]) {
    statusText.textContent = i18n[state.uiLang][key];
  }
}

// ═══════════════════════════════════════
//  Start / Stop Capture
// ═══════════════════════════════════════

async function toggleCapture() {
  if (state.isCapturing) await doStop();
  else await doStart();
}

async function doStart() {
  clearError();
  el.toggleBtn.disabled = true;
  el.btnText.textContent = t('btn_starting');

  try {
    const response = await chrome.runtime.sendMessage({ action: 'startCapture' });

    if (response && response.success) {
      state.isCapturing = true;
      state.lastOriginal = '';
      state.lastTranslated = '';
      updateUI();
      el.audioLevel.classList.remove('hidden');
      startAudioAnimation();

      // Send current UI language to content script
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: 'setLanguage',
            lang: state.uiLang,
          }).catch(() => {});
        }
      });
    } else {
      const errKey = mapErrorToKey(response?.error);
      showError(t(errKey));
      el.toggleBtn.disabled = false;
    }
  } catch (err) {
    showError(t('error_prefix') + err.message);
    el.toggleBtn.disabled = false;
  }
}

async function doStop() {
  try { await chrome.runtime.sendMessage({ action: 'stopCapture' }); } catch {}
  state.isCapturing = false;
  updateUI();
  el.audioLevel.classList.add('hidden');
  stopAudioAnimation();
}

function mapErrorToKey(errorMsg) {
  if (!errorMsg) return 'error_failed';
  const msg = errorMsg.toLowerCase();
  if (msg.includes('no video') || msg.includes('not found')) return 'error_no_video';
  if (msg.includes('cannot capture') || msg.includes('capturestream')) return 'error_no_stream';
  if (msg.includes('no audio track')) return 'error_no_tracks';
  if (msg.includes('already running')) return 'error_capture_running';
  if (msg.includes('chrome://')) return 'error_chrome_page';
  if (msg.includes('connect to')) return 'error_no_server';
  return 'error_failed';
}

// ═══════════════════════════════════════
//  UI Updates
// ═══════════════════════════════════════

function updateUI() {
  if (state.isCapturing) {
    el.toggleBtn.className = 'toggle-btn stop';
    el.btnIcon.innerHTML =
      '<rect width="6" height="16" x="6" y="4" fill="currentColor"/><rect width="6" height="16" x="14" y="4" fill="currentColor"/>';
    el.btnText.textContent = t('btn_stop');
    el.sourceLang.disabled = true;
    el.targetLang.disabled = true;
    el.audioStatus.textContent = t('audio_capturing');
  } else {
    el.toggleBtn.className = 'toggle-btn start';
    el.btnIcon.innerHTML = '<polygon points="5 3 19 12 5 21 5 3"/>';
    el.btnText.textContent = t('btn_start');
    el.toggleBtn.disabled = false;
    el.sourceLang.disabled = false;
    el.targetLang.disabled = false;
  }
}

// ── Audio Level Animation ──
let audioAnimInterval = null;

function startAudioAnimation() {
  const bars = el.audioLevel.querySelectorAll('.bar');
  audioAnimInterval = setInterval(() => {
    bars.forEach((bar, i) => {
      bar.style.height = Math.max(3, Math.random() * 24 * (1 - i * 0.04)) + 'px';
    });
  }, 100);
}

function stopAudioAnimation() {
  if (audioAnimInterval) { clearInterval(audioAnimInterval); audioAnimInterval = null; }
  el.audioLevel.querySelectorAll('.bar').forEach(b => (b.style.height = '3px'));
}

// ═══════════════════════════════════════
//  Translation Display & History
// ═══════════════════════════════════════

function showTranslation(original, translated) {
  if (original === state.lastOriginal) return;
  state.lastOriginal = original;

  el.originalText.textContent = original;
  el.translatedText.textContent = translated;
  el.translationDisplay.classList.remove('hidden');

  addHistory(original, translated);
}

function addHistory(original, translated) {
  const entry = {
    id: Date.now(),
    original,
    translated,
    time: new Date().toLocaleTimeString(state.uiLang === 'ar' ? 'ar-SA' : 'en-US', {
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    }),
  };

  state.history.unshift(entry);
  if (state.history.length > 50) state.history.pop();
  renderHistory();
}

function renderHistory() {
  if (state.history.length === 0) { el.historySection.classList.add('hidden'); return; }
  el.historySection.classList.remove('hidden');
  el.historyList.innerHTML = state.history
    .map(e => `
      <div class="history-entry">
        <div class="time">${e.time}</div>
        <div class="orig">${escapeHtml(e.original)}</div>
        <div class="trans">${escapeHtml(e.translated)}</div>
      </div>
    `).join('');
}

function escapeHtml(text) {
  const d = document.createElement('div');
  d.textContent = text;
  return d.innerHTML;
}

// ═══════════════════════════════════════
//  Error & Settings Helpers
// ═══════════════════════════════════════

function clearError() { el.errorMessage.classList.add('hidden'); }

function showError(msg) {
  if (msg) { el.errorMessage.classList.remove('hidden'); el.errorText.textContent = msg; }
  else { el.errorMessage.classList.add('hidden'); }
}

async function saveSettings() {
  const serverUrl = el.serverUrl.value.trim().replace(/\/$/, '');
  const chunkInterval = parseInt(el.chunkInterval.value) || 4;

  await chrome.storage.local.set({
    serverUrl,
    sourceLang: el.sourceLang.value,
    targetLang: el.targetLang.value,
    chunkInterval: Math.max(2, Math.min(10, chunkInterval)),
  });

  state.serverUrl = serverUrl;
  el.settingsPanel.classList.add('hidden');
  await checkServerConnection();

  const btn = el.saveSettings;
  btn.textContent = t('btn_saved');
  btn.style.background = '#10b981';
  setTimeout(() => { btn.textContent = t('btn_save'); btn.style.background = ''; }, 1500);
}

// ═══════════════════════════════════════
//  Message Listener (from background)
// ═══════════════════════════════════════

chrome.runtime.onMessage.addListener((msg) => {
  switch (msg.action) {
    case 'translationResult':
      showTranslation(msg.original, msg.translated);
      break;
    case 'captureStarted':
      el.audioStatus.textContent = t('audio_capturing');
      break;
    case 'captureStopped':
      state.isCapturing = false;
      updateUI();
      el.audioLevel.classList.add('hidden');
      stopAudioAnimation();
      el.toggleBtn.disabled = false;
      break;
    case 'captureError':
      state.isCapturing = false;
      updateUI();
      el.toggleBtn.disabled = false;
      showError(msg.error || t('error_failed'));
      break;
  }
});

// ═══════════════════════════════════════
//  Event Bindings
// ═══════════════════════════════════════

el.langToggle.addEventListener('click', toggleLanguage);
el.toggleBtn.addEventListener('click', toggleCapture);

el.clearHistory.addEventListener('click', () => { state.history = []; renderHistory(); });
el.settingsToggle.addEventListener('click', () => { el.settingsPanel.classList.toggle('hidden'); });
el.saveSettings.addEventListener('click', saveSettings);

el.sourceLang.addEventListener('change', async () => {
  state.lastOriginal = '';
  await chrome.storage.local.set({ sourceLang: el.sourceLang.value });
});

el.targetLang.addEventListener('change', async () => {
  state.lastTranslated = '';
  await chrome.storage.local.set({ targetLang: el.targetLang.value });
});

// ── Start ──
init();
