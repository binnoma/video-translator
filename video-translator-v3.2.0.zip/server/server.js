/**
 * ══════════════════════════════════════════════════════
 *   Video Translator Server v3.0 — Free APIs Only
 * ══════════════════════════════════════════════════════
 *
 * ✅ No SDK or paid API key needed
 * ✅ Uses completely free APIs:
 *    - Speech-to-Text: Google Speech API (free tier)
 *    - Translation: MyMemory API (free, no key)
 *
 * How to run:
 *    node server.js
 */

const http = require('http');
const https = require('https');

// ── Config ──
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

// ── Translation Cache ──
const cache = new Map();

// ── Language Maps ──
const langToBcp47 = {
  'zh-CN': 'zh-CN', 'en-US': 'en-US', 'ja-JP': 'ja-JP',
  'ko-KR': 'ko-KR', 'fr-FR': 'fr-FR', 'es-ES': 'es-ES',
  'ru-RU': 'ru-RU', 'tr-TR': 'tr-TR', 'de-DE': 'de-DE',
  'pt-BR': 'pt-BR', 'hi-IN': 'hi-IN', 'ar-SA': 'ar-SA',
};

const langToMyMemory = {
  'zh-CN': 'zh', 'en-US': 'en', 'ja-JP': 'ja',
  'ko-KR': 'ko', 'fr-FR': 'fr', 'es-ES': 'es',
  'ru-RU': 'ru', 'tr-TR': 'tr', 'de-DE': 'de',
  'pt-BR': 'pt', 'hi-IN': 'hi', 'ar-SA': 'ar',
};

// ═══════════════════════════════════════
//  HTTP Helpers
// ═══════════════════════════════════════

function sendJSON(res, code, data) {
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => (body += chunk));
    req.on('end', () => {
      try { resolve(JSON.parse(body)); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function httpGet(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { timeout: 15000 }, (res) => {
      let data = '';
      res.on('data', chunk => (data += chunk));
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    }).on('error', reject);
  });
}

function httpPost(url, headers, bodyStr) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const isHttps = urlObj.protocol === 'https:';
    const lib = isHttps ? https : http;
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || (isHttps ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...headers },
      timeout: 30000,
    };
    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', chunk => (data += chunk));
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Request timeout')); });
    req.write(bodyStr);
    req.end();
  });
}

// ═══════════════════════════════════════
//  Speech-to-Text (STT)
//  Uses Google Speech API (free tier)
// ═══════════════════════════════════════

async function handleTranscribe(req, res, body) {
  try {
    const { audioBase64, lang } = body;
    if (!audioBase64) {
      return sendJSON(res, 400, { error: 'Audio data is required' });
    }

    const language = langToBcp47[lang] || 'en-US';
    const audioBuffer = Buffer.from(audioBase64, 'base64');

    console.log(`  [STT] Processing audio (${audioBuffer.length} bytes, lang: ${language})...`);

    const text = await speechToText(audioBuffer, language);

    if (text) {
      console.log(`  [STT] Result: "${text.substring(0, 80)}${text.length > 80 ? '...' : ''}"`);
    } else {
      console.log('  [STT] No speech detected');
    }

    sendJSON(res, 200, { success: true, text: text || '' });
  } catch (err) {
    console.error('  [STT] Error:', err.message);
    sendJSON(res, 500, { error: 'Speech recognition failed: ' + err.message });
  }
}

async function speechToText(audioBuffer, language) {
  // Method 1: Google Speech API
  try {
    const text = await googleSpeechAPI(audioBuffer, language);
    if (text && text.trim().length > 0) return text.trim();
  } catch (e) {
    console.log('  [STT] Google Speech API failed, trying alternative...');
  }

  // Method 2: Alternative (requires WIT_AI_TOKEN env var)
  try {
    const text = await alternativeSTT(audioBuffer, language);
    if (text && text.trim().length > 0) return text.trim();
  } catch (e) {
    console.log('  [STT] Alternative also failed');
  }

  return '';
}

async function googleSpeechAPI(audioBuffer, language) {
  return new Promise((resolve, reject) => {
    const googleKey = 'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw';

    const postData = {
      config: {
        encoding: 'LINEAR16',
        sampleRateHertz: 16000,
        languageCode: language,
        enableAutomaticPunctuation: true,
      },
      audio: {
        content: audioBuffer.toString('base64'),
      },
    };

    const bodyStr = JSON.stringify(postData);

    const options = {
      hostname: 'speech.googleapis.com',
      path: `/v1/speech:recognize?key=${googleKey}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(bodyStr),
      },
      timeout: 15000,
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => (data += chunk));
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.results && json.results.length > 0) {
            const transcript = json.results
              .map(
                r =>
                  r.alternatives && r.alternatives[0] && r.alternatives[0].transcript
              )
              .filter(Boolean)
              .join(' ');
            resolve(transcript);
          } else {
            resolve('');
          }
        } catch {
          resolve('');
        }
      });
    });

    req.on('error', () => resolve(''));
    req.on('timeout', () => { req.destroy(); resolve(''); });
    req.write(bodyStr);
    req.end();
  });
}

async function alternativeSTT(audioBuffer, language) {
  const witToken = process.env.WIT_AI_TOKEN;
  if (!witToken) {
    throw new Error('No alternative STT available. Set WIT_AI_TOKEN env var for Wit.ai.');
  }

  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.wit.ai',
      path: '/speech?v=20240327',
      method: 'POST',
      headers: {
        Authorization: `Bearer ${witToken}`,
        'Content-Type': 'audio/wav',
      },
      timeout: 15000,
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => (data += chunk));
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve(json.text || json._text || '');
        } catch {
          resolve('');
        }
      });
    });

    req.on('error', () => resolve(''));
    req.on('timeout', () => { req.destroy(); resolve(''); });
    req.write(audioBuffer);
    req.end();
  });
}

// ═══════════════════════════════════════
//  Translation (MT)
//  Uses MyMemory API — completely free
// ═══════════════════════════════════════

async function handleTranslate(req, res, body) {
  try {
    const { text, targetLang, sourceLang } = body;
    if (!text || !targetLang) {
      return sendJSON(res, 400, { error: 'Text and target language are required' });
    }

    const source = langToMyMemory[sourceLang] || 'en';
    const target = langToMyMemory[targetLang] || 'ar';

    // Check cache
    const cacheKey = `${source}|${target}|${text.substring(0, 200)}`;
    if (cache.has(cacheKey)) {
      console.log(`  [MT] Cache hit: "${text.substring(0, 40)}..."`);
      return sendJSON(res, 200, { translatedText: cache.get(cacheKey), cached: true });
    }

    console.log(`  [MT] Translating "${text.substring(0, 40)}..." (${source} → ${target})`);

    const translated = await myMemoryTranslate(text, source, target);

    if (!translated) {
      return sendJSON(res, 500, { error: 'Translation failed' });
    }

    console.log(`  [MT] Result: "${translated.substring(0, 60)}..."`);

    // Save to cache
    cache.set(cacheKey, translated);
    if (cache.size > 500) cache.delete(cache.keys().next().value);

    sendJSON(res, 200, { translatedText: translated });
  } catch (err) {
    console.error('  [MT] Error:', err.message);
    sendJSON(res, 500, { error: 'Translation error: ' + err.message });
  }
}

async function myMemoryTranslate(text, from, to) {
  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text.substring(0, 500))}&langpair=${from}|${to}&de=video-translator@extension.com`;

  try {
    const result = await httpGet(url);
    const json = JSON.parse(result.body);

    if (json.responseStatus === 200 && json.responseData) {
      return json.responseData.translatedText;
    }
    return null;
  } catch (err) {
    console.error('  [MT] MyMemory failed:', err.message);
    return await libreTranslate(text, from, to);
  }
}

async function libreTranslate(text, from, to) {
  try {
    const url = 'https://libretranslate.de/translate';
    const result = await httpPost(url, {}, JSON.stringify({
      q: text.substring(0, 500),
      source: from,
      target: to,
      format: 'text',
    }));
    const json = JSON.parse(result.body);
    return json.translatedText || null;
  } catch {
    return null;
  }
}

// ═══════════════════════════════════════
//  Health Check
// ═══════════════════════════════════════

function handleHealth(req, res) {
  sendJSON(res, 200, {
    status: 'ok',
    service: 'Video Translator Server v3.0',
    features: {
      stt: 'Google Speech API (free)',
      mt: 'MyMemory API (free)',
    },
    uptime: Math.floor(process.uptime()),
    cacheSize: cache.size,
  });
}

// ═══════════════════════════════════════
//  Request Router
// ═══════════════════════════════════════

async function handleRequest(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;
  const method = req.method;

  // CORS preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    res.end();
    return;
  }

  try {
    if (method === 'GET' && pathname === '/api/health') return handleHealth(req, res);

    if (method === 'POST' && pathname === '/api/transcribe') {
      const body = await readBody(req);
      return await handleTranscribe(req, res, body);
    }

    if (method === 'POST' && pathname === '/api/translate') {
      const body = await readBody(req);
      return await handleTranslate(req, res, body);
    }

    // Root page
    if (method === 'GET' && (pathname === '/' || pathname === '')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(`<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Video Translator Server</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Tahoma,sans-serif;background:#0f172a;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh}
.card{background:#1e293b;border:1px solid rgba(255,255,255,.06);border-radius:20px;padding:40px;max-width:520px;text-align:center}
.icon{font-size:48px;margin-bottom:16px}
h1{font-size:22px;color:#fff;margin-bottom:8px}
.badge{display:inline-flex;align-items:center;gap:6px;background:rgba(20,184,166,.1);color:#14b8a6;padding:6px 14px;border-radius:20px;font-size:13px;margin:12px 0 20px}
.dot{width:8px;height:8px;background:#14b8a6;border-radius:50%;animation:p 2s infinite}
@keyframes p{0%,100%{opacity:1}50%{opacity:.3}}
.info{background:rgba(255,255,255,.03);border-radius:12px;padding:16px;margin-bottom:16px;text-align:left}
.info h3{font-size:13px;color:#94a3b8;margin-bottom:8px}
.api-row{display:flex;justify-content:space-between;padding:6px 0;font-size:12px}
.api-row span:first-child{color:#64748b}
.api-row span:last-child{color:#14b8a6;font-weight:600}
.note{font-size:11px;color:#475569;line-height:1.8}
</style></head>
<body><div class="card">
<div class="icon">&#127760;</div>
<h1>Video Translator Server v3.0</h1>
<div class="badge"><div class="dot"></div> Running &mdash; Free APIs</div>
<div class="info">
<h3>Available Services:</h3>
<div class="api-row"><span>Speech-to-Text</span><span>Google Speech (free)</span></div>
<div class="api-row"><span>Translation</span><span>MyMemory API (free)</span></div>
</div>
<p class="note">
Server running on port ${PORT}<br>
No API key or SDK required<br>
Uses free services only<br>
Press Ctrl+C to stop
</p></div></body></html>`);
      return;
    }

    sendJSON(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('  Error:', err);
    sendJSON(res, 500, { error: 'Server error' });
  }
}

// ═══════════════════════════════════════
//  Start Server
// ═══════════════════════════════════════

function start() {
  console.log('');
  console.log('  ======================================');
  console.log('  Video Translator Server v3.0 (Free)');
  console.log('  ======================================');
  console.log('');
  console.log('  No SDK or API key needed');
  console.log('  STT:   Google Speech API (free)');
  console.log('  MT:    MyMemory API (free)');
  console.log('');

  const server = http.createServer(handleRequest);

  server.listen(PORT, HOST, () => {
    console.log(`  Server: http://localhost:${PORT}`);
    console.log('');
    console.log('  Endpoints:');
    console.log('    POST /api/transcribe  (audio -> text)');
    console.log('    POST /api/translate   (translate text)');
    console.log('    GET  /api/health      (server status)');
    console.log('');
    console.log('  Press Ctrl+C to stop');
    console.log('');
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`  Port ${PORT} is in use. Try: PORT=3001 node server.js`);
    } else {
      console.error('  Error:', err.message);
    }
    process.exit(1);
  });
}

start();
